<?php
     
	 $server = "sql208.epizy.com";
	 $username = "epiz_28724687";
	 $password = "PUCFbNgnGkYuI";
	 $dbname = "epiz_28724687_shriicodes";

/* Connection to database */
	$conn =mysqli_connect("localhost","root","","shriicodes");

	/* Check connection */
	if(mysqli_connect_error()) {
		echo "Connection failed";
		printf("Error : %s",mysqli_connect_error());
	}

?>
