<style media="screen">

.bg {
background: url('https://wallup.net/wp-content/uploads/2019/09/611548-blog-blogger-computer-internet-typography-text-media-blogging-social.jpg');
background-repeat: no-repeat;
background-position: top;
background-size: contain;
height: 1000px;
background-color: #79c4fc;
}
footer {
  text-align: center;
  padding: 3px;
  background-color: #20f5ee;
  color: #212424;
}

</style>

<?php
$index_url='index.php';
$posts_url='posts/posts.php';
$top_posts_url='posts/topposts.php';
$post_url='posts/post.php';
$newpost_url='posts/newpost.php';
$login_url='users/login.php';
$logout_url='users/logout.php';
$register_url='users/register.php';
$search_url='posts/search.php';
$contact_us_url='users/contact_us.php';

session_start();

include("include/navbar.php");
include("include/bootstrap_cdn.php");

if(isset($_SESSION['username'])) {
	header("location:posts/posts.php");
}

?>

<div class="row">
	<div class="bg"></div>
</div>

<footer>
  <p>Author: raparthi srikanth</p>
  <p><a href="raparthisrikanth29@gmail.com">raparthisrikanth29@gmail.com</a></p>
</footer>
